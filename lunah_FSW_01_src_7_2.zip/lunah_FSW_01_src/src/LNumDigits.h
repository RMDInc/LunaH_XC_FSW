/*
 * LNumDigits.h
 *
 *  Created on: Mar 22, 2017
 *      Author: GStoddard
 */

#ifndef LNUMDIGITS_H_
#define LNUMDIGITS_H_

int LNumDigits(int n);

#endif /* LNUMDIGITS_H_ */
