/*
 * process_data.h
 *
 *  Created on: May 9, 2018
 *      Author: gstoddard
 */

#ifndef SRC_PROCESS_DATA_H_
#define SRC_PROCESS_DATA_H_

#include "ff.h"

//function prototype
int process_data(unsigned int * data_array, FIL data_file);

#endif /* SRC_PROCESS_DATA_H_ */
